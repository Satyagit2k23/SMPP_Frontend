import { memo, SVGProps } from 'react';

const VisibleSvgIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 20 20' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_9_543)'>
      <path
        fillRule='evenodd'
        clipRule='evenodd'
        d='M9.99991 3.75C15.4371 3.75 19.6942 9.57753 19.8729 9.82567C20.0424 10.0608 20.0424 10.3803 19.8729 10.6157C19.6942 10.8636 15.4371 16.6912 9.99991 16.6912C4.56275 16.6912 0.305392 10.8636 0.126914 10.6155C-0.0423048 10.3801 -0.0423048 10.0608 0.126914 9.82543C0.305392 9.57753 4.56275 3.75 9.99991 3.75ZM1.49923 10.2201C2.52607 11.4846 5.99487 15.3525 9.99992 15.3525C14.0136 15.3525 17.4751 11.4866 18.5006 10.2211C17.4733 8.95592 14.0048 5.08875 9.99992 5.08875C5.98627 5.08875 2.52474 8.95457 1.49923 10.2201Z'
        fill='#6D7D8F'
      />
      <path
        fillRule='evenodd'
        clipRule='evenodd'
        d='M6.04395 10.2206C6.04395 8.00607 7.81868 6.20435 10 6.20435C12.1813 6.20435 13.9561 8.00607 13.9561 10.2206C13.9561 12.4351 12.1813 14.2368 10 14.2368C7.81868 14.2368 6.04395 12.4351 6.04395 10.2206Z'
        fill='#6D7D8F'
      />
    </g>
    <defs>
      <clipPath id='clip0_9_543'>
        <rect width={20} height={20} fill='white' />
      </clipPath>
    </defs>
  </svg>
);
const Memo = memo(VisibleSvgIcon);
export { Memo as VisibleSvgIcon };
