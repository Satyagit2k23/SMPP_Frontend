import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { BgIcon } from './BgIcon.js';
import { FluentCheckboxChecked16FilledI } from './FluentCheckboxChecked16FilledI.js';
import { Google_icon_btnSvgIcon } from './Google_icon_btnSvgIcon.js';
import classes from './Login.module.css';
import { Microsoft_icon_btnSvgIcon } from './Microsoft_icon_btnSvgIcon.js';
import { PhMetaLogoLightIcon } from './PhMetaLogoLightIcon.js';
import { RadixIconsDropdownMenuIcon } from './RadixIconsDropdownMenuIcon.js';
import { Sf_btn_iconSvgIcon } from './Sf_btn_iconSvgIcon.js';
import { VisibleSvgIcon } from './VisibleSvgIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 5:446 */
export const Login: FC<Props> = memo(function Login(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <div className={classes.rectangle52}></div>
      <div className={classes.frame32}></div>
      <div className={classes.bG}>
        <BgIcon className={classes.icon} />
      </div>
      <div className={classes.divNonCreateAccount}>
        <div className={classes.ziRegularLogin}>
          <div className={classes.mainHeading1LogIn}>Log In</div>
          <div className={classes.mainFormLabelUsername}>Username </div>
          <div className={classes.mainFormLabelUsername2}>Language</div>
          <div className={classes.mainFormButtonUsernameCanBeEma}></div>
          <div className={classes.mainFormButtonUsernameCanBeEma2}>
            <div className={classes.informationIconSvgFill}></div>
          </div>
          <div className={classes.mainForm}>
            <div className={classes.user2SvgFill}></div>
            <div className={classes.spanOFormInputNameUsernameOutl}></div>
          </div>
          <div className={classes.mainForm2}>
            <div className={classes.user2SvgFill2}>
              <div className={classes.radixIconsDropdownMenu}>
                <RadixIconsDropdownMenuIcon className={classes.icon2} />
              </div>
            </div>
          </div>
          <div className={classes.mainFormLabelPassword}>Password </div>
          <div className={classes.mainForm3}>
            <div className={classes.lock2SvgFill}></div>
            <button className={classes.button}>
              <div className={classes.visibleSvg}>
                <div className={classes.visibleSvgFill}>
                  <div className={classes.visibleSvg2}>
                    <VisibleSvgIcon className={classes.icon3} />
                  </div>
                </div>
              </div>
            </button>
          </div>
          <div className={classes.mainFormLabelRememberMe}>Remember me</div>
          <div className={classes.mainFormLinkForgotPassword}>Forgot password?</div>
          <div className={classes.main}></div>
          <div className={classes.mainOr}>Or</div>
          <div className={classes.main2}></div>
          <button className={classes.mainButton}>
            <div className={classes.google_icon_btnSvg}>
              <div className={classes.google_icon_btnSvgFill}>
                <div className={classes.google_icon_btnSvg2}>
                  <Google_icon_btnSvgIcon className={classes.icon4} />
                </div>
              </div>
            </div>
            <div className={classes.p}>
              <div className={classes.google}>Google</div>
            </div>
          </button>
          <button className={classes.mainButton2}>
            <div className={classes.microsoft_icon_btnSvg}>
              <div className={classes.microsoft_icon_btnSvgFill}>
                <div className={classes.microsoft_icon_btnSvg2}>
                  <Microsoft_icon_btnSvgIcon className={classes.icon5} />
                </div>
              </div>
            </div>
            <div className={classes.p2}>
              <div className={classes.office365}>Office 365</div>
            </div>
          </button>
          <button className={classes.mainButton3}>
            <div className={classes.sf_btn_iconSvg}>
              <div className={classes.sf_btn_iconSvgFill}>
                <div className={classes.sf_btn_iconSvg2}>
                  <Sf_btn_iconSvgIcon className={classes.icon6} />
                </div>
              </div>
            </div>
            <div className={classes.p3}>
              <div className={classes.salesforce}>Salesforce</div>
            </div>
          </button>
          <div className={classes.fluentCheckboxChecked16Filled}>
            <FluentCheckboxChecked16FilledI className={classes.icon7} />
          </div>
          <div className={classes.login}>
            <div className={classes.login2}>Login</div>
          </div>
        </div>
        <div className={classes.gladYouReBack}>Glad you’re back.!</div>
      </div>
      <div className={classes.divLoginPageMainBottom}>
        <div className={classes._2023HITechInfosystem}>© 2023 HI Tech Infosystem</div>
        <div className={classes.link}>
          <div className={classes.termsConditions}>Terms &amp; Conditions</div>
        </div>
        <div className={classes.link2}>
          <div className={classes.privacy}>Privacy</div>
        </div>
        <div className={classes.linkStatus}>Status</div>
      </div>
      <div className={classes.phMetaLogoLight}>
        <PhMetaLogoLightIcon className={classes.icon8} />
      </div>
    </div>
  );
});
