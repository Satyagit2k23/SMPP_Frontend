import { memo, SVGProps } from 'react';

const Microsoft_icon_btnSvgIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 14 17' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_9_551)'>
      <path
        d='M8.67222 0.5L13.054 1.86992L13.0544 15.152L8.50641 16.5L0.897999 13.5274L8.67222 14.7285V3.12108L8.50587 3.16203L8.50641 2.94556L3.10567 4.29349V12.1566L0.5 13.2125L0.500008 3.72015L8.67222 0.5Z'
        fill='#DE3C00'
      />
    </g>
    <defs>
      <clipPath id='clip0_9_551'>
        <rect width={14} height={17} fill='white' />
      </clipPath>
    </defs>
  </svg>
);
const Memo = memo(Microsoft_icon_btnSvgIcon);
export { Memo as Microsoft_icon_btnSvgIcon };
