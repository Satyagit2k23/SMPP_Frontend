import { memo, SVGProps } from 'react';

const BgIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1712 1716' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g filter='url(#filter0_f_9_533)'>
      <path
        d='M1060.59 561.385C1060.59 777.392 857.062 952.5 606 952.5C354.938 952.5 151.413 777.392 151.413 561.385C151.413 345.378 354.938 170.27 606 170.27C857.062 170.27 1060.59 345.378 1060.59 561.385Z'
        fill='url(#paint0_angular_9_533)'
        fillOpacity={0.6}
      />
    </g>
    <g filter='url(#filter1_b_9_533)'>
      <ellipse
        cx={547.857}
        cy={618.418}
        rx={547.857}
        ry={618.418}
        transform='matrix(0.964794 -0.263009 0.337983 0.941152 5.22028 420.115)'
        fill='url(#paint1_linear_9_533)'
        fillOpacity={0.15}
      />
      <ellipse
        cx={547.857}
        cy={618.418}
        rx={547.857}
        ry={618.418}
        transform='matrix(0.964794 -0.263009 0.337983 0.941152 5.22028 420.115)'
        stroke='url(#paint2_linear_9_533)'
        strokeWidth={4.19417}
      />
    </g>
    <mask
      id='mask0_9_533'
      style={{
        maskType: 'alpha',
      }}
      maskUnits='userSpaceOnUse'
      x={218}
      y={251}
      width={1050}
      height={1214}
    >
      <ellipse
        cx={566.781}
        cy={567.058}
        rx={566.781}
        ry={567.058}
        transform='matrix(0.667289 -0.744799 0.641272 0.767314 0.958527 845.076)'
        fill='#C4C4C4'
      />
    </mask>
    <g mask='url(#mask0_9_533)' />
    <g filter='url(#filter2_f_9_533)'>
      <path
        d='M1711.67 884.369C1711.67 1127.92 1624.46 1322.47 1342.87 1353.21C1141.21 1353.21 937.16 1226.39 937.16 912.23C937.16 606.163 1166.37 346.353 1368.02 346.353C1569.67 346.353 1711.67 640.822 1711.67 884.369Z'
        fill='url(#paint3_angular_9_533)'
      />
    </g>
    <defs>
      <filter
        id='filter0_f_9_533'
        x={-90.3745}
        y={-71.517}
        width={1392.75}
        height={1265.8}
        filterUnits='userSpaceOnUse'
        colorInterpolationFilters='sRGB'
      >
        <feFlood floodOpacity={0} result='BackgroundImageFix' />
        <feBlend mode='normal' in='SourceGraphic' in2='BackgroundImageFix' result='shape' />
        <feGaussianBlur stdDeviation={120.894} result='effect1_foregroundBlur_9_533' />
      </filter>
      <filter
        id='filter1_b_9_533'
        x={130.179}
        y={214.315}
        width={1225.25}
        height={1287.47}
        filterUnits='userSpaceOnUse'
        colorInterpolationFilters='sRGB'
      >
        <feFlood floodOpacity={0} result='BackgroundImageFix' />
        <feGaussianBlur in='BackgroundImageFix' stdDeviation={20.9709} />
        <feComposite in2='SourceAlpha' operator='in' result='effect1_backgroundBlur_9_533' />
        <feBlend mode='normal' in='SourceGraphic' in2='effect1_backgroundBlur_9_533' result='shape' />
      </filter>
      <filter
        id='filter2_f_9_533'
        x={390.034}
        y={-200.773}
        width={1868.76}
        height={2101.11}
        filterUnits='userSpaceOnUse'
        colorInterpolationFilters='sRGB'
      >
        <feFlood floodOpacity={0} result='BackgroundImageFix' />
        <feBlend mode='normal' in='SourceGraphic' in2='BackgroundImageFix' result='shape' />
        <feGaussianBlur stdDeviation={273.563} result='effect1_foregroundBlur_9_533' />
      </filter>
      <radialGradient
        id='paint0_angular_9_533'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(598.022 484.418) rotate(104.292) scale(428.341 303.593)'
      >
        <stop offset={0.513031} stopColor='#E54EAB' />
        <stop offset={0.647016} stopColor='#09FBD3' />
        <stop offset={0.80796} stopColor='#1EEDD2' />
        <stop offset={0.971084} stopColor='#201580' />
      </radialGradient>
      <linearGradient
        id='paint1_linear_9_533'
        x1={233.406}
        y1={117.097}
        x2={1085.04}
        y2={939.853}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#FF53BC' />
        <stop offset={1} stopColor='#0AFCD4' />
      </linearGradient>
      <linearGradient
        id='paint2_linear_9_533'
        x1={172.323}
        y1={176.167}
        x2={1048.09}
        y2={912.203}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#FE53BB' />
        <stop offset={0.444915} stopColor='#919EC6' stopOpacity={0} />
        <stop offset={0.727921} stopColor='#4CCDCC' stopOpacity={0} />
        <stop offset={1} stopColor='#09FBD3' />
      </linearGradient>
      <radialGradient
        id='paint3_angular_9_533'
        cx={0}
        cy={0}
        r={1}
        gradientUnits='userSpaceOnUse'
        gradientTransform='translate(1294.83 861.311) rotate(100.674) scale(481.008 380.339)'
      >
        <stop offset={0.0290006} stopColor='#561BBE' />
        <stop offset={0.438386} stopColor='#09FBD3' />
        <stop offset={0.613412} stopColor='#FE54BC' />
      </radialGradient>
    </defs>
  </svg>
);
const Memo = memo(BgIcon);
export { Memo as BgIcon };
